from omni.kit.scripting import BehaviorScript
import omni
import omni.physx
from pxr import Gf, Sdf, PhysxSchema, UsdGeom, Usd
from omni.physx.scripts import utils
from omni.physx import get_physx_scene_query_interface
from omni.physx import get_physx_interface, get_physx_simulation_interface
from omni.physx.scripts.physicsUtils import *
import carb


class PackageCollTest(BehaviorScript):
    def on_init(self):
        self.pallet_path = '/World/Pallet'
        self.reset_character()

    def on_destroy(self):
        self.pallet = None
        self._contact_report_sub.unsubscribe()
        self._contact_report_sub = None

    def on_play(self):
        self.reset_character()

    def on_stop(self):
        collision_attr = self.prim.GetAttribute("physics:collisionEnabled")
        collision_attr.Set(True)

        self.on_destroy()

    def on_update(self, current_time: float, delta_time: float):
        print(f"{__class__.__name__}.on_update(current_time={current_time}, delta_time={delta_time})->{self.prim_path}")

    def reset_character(self):
        

        collision_attr = self.prim.GetAttribute("physics:collisionEnabled")
        collision_attr.Set(True)

        self.contact_thresh = 1 

        # apply contact report
        ### This would be an example of each object managing their own collision
        self._contact_report_sub = get_physx_simulation_interface().subscribe_contact_report_events(self._on_contact_report_event)
        contactReportAPI = PhysxSchema.PhysxContactReportAPI.Apply(self.prim)
        contactReportAPI.CreateThresholdAttr().Set(self.contact_thresh)
        #######

        # Assign this as an agent instance 
        self.package = str(self.prim_path)

    def on_update(self, current_time: float, delta_time: float):
        """
        Called on every update. Initializes character at start, 
        publishes character positions and executes character commands.
        :param float current_time: current time in seconds.
        :param float delta_time: time elapsed since last update.
        """

        return 

    def _on_contact_report_event(self, contact_headers, contact_data):

        # Check if a collision was because of a player
        for contact_header in contact_headers:

            collider_1 = str(PhysicsSchemaTools.intToSdfPath(contact_header.actor0))
            collider_2 = str(PhysicsSchemaTools.intToSdfPath(contact_header.actor1))

            contacts = [collider_1, collider_2]

            if  self.pallet_path in contacts and self.prim_path in contacts:
                collision_attr = self.prim.GetAttribute("physics:collisionEnabled")
                collision_attr.Set(False)